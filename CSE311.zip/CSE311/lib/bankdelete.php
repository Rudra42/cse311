<?php

include "connection.php";
if(isset($_GET['id'])){
    //echo $_GET['id'];
    $delete_id=$_GET['id'];
    
    $delete_sql= "DELETE FROM bank_info where id=$delete_id";
    if($conn->query( $delete_sql)){
        header("location:../adminbank.php");
    }
    else{
        die($conn->error);
    }
}
else{
    header("location:../adminbank.php");
}
?>