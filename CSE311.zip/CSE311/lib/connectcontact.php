<?php
    include "lib/connection.php";
    $result="";
      //insert query
        if(isset($_POST['add_data'])){
            $age= $_POST['student_age'];
           $name= $_POST['student_name'];
              
           
            
              $insert_sql= "INSERT INTO contact_info (age,Name) values ('$age','$name')";
           
                
                      if($conn->query($insert_sql)){
                $result="Successfully Submitted!";
              }
                      else{
                        die($conn->error);
                        }
               
          
    }

    //select query
    
    $select_sql="SELECT * FROM contact_info";
    $select_query=$conn->query($select_sql);
    
    //echo $select_query->num_rows;
        
    
?>
