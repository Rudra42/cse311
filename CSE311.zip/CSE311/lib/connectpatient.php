<?php
    include "lib/connection.php";
    $result="";
      //insert query
        if(isset($_POST['add_data'])){
            $fname= $_POST['student_fname'];
            $lname= $_POST['student_lname'];
            $age= $_POST['student_age'];
            $email= $_POST['student_email'];
            $gender= $_POST['student_gender'];
            $pass= md5($_POST['student_pass']);
            $confirm= md5($_POST['student_confirm']);
              
            if($pass==$confirm){
            
            $insert_sql= "INSERT INTO patient_info (pfirst_name,p_bloodgroup,page,pemail,pgender,p_phone) values ('$fname','$lname',$age,'$email','$gender','$pass')";
            if (strlen($pass)<6){
                  $result= "Password should be atleast 6 characters!";
              } 
                else{
                      if($conn->query($insert_sql)){
                $result="Successfully Submitted!";
              }
                      else{
                        die($conn->error);
                        }
                }
          
           }
           else{
           $result= "Password didn't match!Try again";
           }
    }

    //select query
    
    $select_sql="SELECT * FROM patient_info";
    $select_query=$conn->query($select_sql);
    
    //echo $select_query->num_rows;
        
    
?>
