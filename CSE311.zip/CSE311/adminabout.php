<!DOCTYPE html>
<html lang="en">

<head>
    <title>About</title>
    <meta charset="utf-8">
    <meta name="format-detection" content="telephone=no" />
    <link rel="icon" href="images/favicon.ico">
    <link rel="shortcut icon" href="images/favicon.ico" />
    <link rel="stylesheet" href="css/style.css">
    <script src="js/jquery.js"></script>
    <script src="js/jquery-migrate-1.1.1.js"></script>
    <script src="js/jquery.easing.1.3.js"></script>
    <script src="js/script.js"></script>
    <script src="js/superfish.js"></script>
    <script src="js/jquery.equalheights.js"></script>
    <script src="js/jquery.mobilemenu.js"></script>
    <script src="js/tmStickUp.js"></script>
    <script src="js/jquery.ui.totop.js"></script>
    <script>
        $(window).load(function() {
            $().UItoTop({
                easingType: 'easeOutQuart'
            });
            $('#stuck_container').tmStickUp({});
        });

    </script>
    <!--[if lt IE 8]>
 <div style=' clear: both; text-align:center; position: relative;'>
   <a href="http://windows.microsoft.com/en-US/internet-explorer/products/ie/home?ocid=ie6_countdown_bannercode">
     <img src="http://storage.ie6countdown.com/assets/100/images/banners/warning_bar_0000_us.jpg" border="0" height="42" width="820" alt="You are using an outdated browser. For a faster, safer browsing experience, upgrade for free today." />
   </a>
</div>
<![endif]-->
    <!--[if lt IE 9]>
<script src="js/html5shiv.js"></script>
<link rel="stylesheet" media="screen" href="css/ie.css">
<![endif]-->
</head>

<body class="" id="top">
    <!--==============================
              header
=================================-->
    <header>
        <div class="container_12">
            <div class="grid_12">
                <h1 class="logo">
                    <a href="index.php">
          Youth
          <span>For BLood</span>
        </a>
                </h1>
            </div>
            <div class="clear"></div>
        </div>
        <section id="stuck_container">
            <!--==============================
              Stuck menu
  =================================-->
            <div class="container_12">
                <div class="grid_12">
                    <div class="navigation ">
                        <nav>
                            <ul class="sf-menu">
                                <li><a href="admin.php">Home</a></li>
                                <li class="current"><a href="adminabout.php">About</a></li>
                                <li><a href="adminblood.php">Available Bloods</a></li>
                                <li><a href="adminpatient.php">Available Patients</a></li>
                                <li><a href="adminbank.php">Available Blood Bank</a></li>
                                  <li><a href="adminmsg.php">Message</a></li>
                         
                            </ul>
                        </nav>
                        <div class="clear"></div>
                    </div>
                    <div class="clear"></div>
                </div>
                <div class="clear"></div>
            </div>
        </section>
    </header>
    <!--=====================
          Content
======================-->
    <section id="content">
        <div class="ic">More Website Templates @ TemplateMonster.com - September22, 2014!</div>
        <div class="container_12">
            <div class="grid_8">
                <h2 class="ta__center">What We Believe</h2>
            </div>
            <div class="clear"></div>
            <div class="grid_8">
                <div class="grid_4 alpha">
                    <div class="block-3">
                        <img src="images/page2_img1.jpg" alt="" class="img_inner">
                        <div class="text1 tx__1">Humanity</div>
                        Humanity is the human race, which includes everyone on Earth. It's also a word for the qualities that make us human, such as the ability to love and have compassion, be creative, and not be a robot or alien. The word humanity is from the Latin humanitas for "human nature, kindness.”
                    </div>
                </div>
                <div class="grid_4 omega">
                    <div class="block-3">
                        <img src="images/page2_img2.jpg" alt="" class="img_inner">
                        <div class="text1 tx__1">Always Be Humble</div>
                        Have more humility. Remember you don't know the limits of your own abilities. Successful or not, if you keep pushing beyond yourself, you will enrich your own life--and maybe even please a few strangers.--A.L. Kennedy
                    </div>
                </div>

            </div>
            <div class="grid_4">
                <ul class="list-1">
                    <li>
                        <div class="count">1</div> <br>
                        <a href="#">Blood is the most precious gift that anyone can give to another person — the gift of life. A decision to donate your blood can save a life,</a>
                    </li>
                    <li>
                        <div class="count">2</div> <br>
                        <a href="#"> Blood donation reduces the risk of heart attacks and strokes, too.Blood Donation will cost you nothing but it will save a life!</a>
                    </li>
                    <li>
                        <div class="count">3</div> <br>
                        <a href="#">The blood you donate gives someone another chance at life. One day that someone may be a close relative, a friend, a loved one—or even you.</a>
                    </li>

                </ul>
            </div>
            <div class="clear"></div>
            <div class="grid_12">
                <div class="block-4">
                    <div class="block-4_title">Know Your Blood Group</div>The importance of knowing your blood type is to prevent the risk of you receiving an incompatible blood type at a time of need, such as during a blood transfusion or during surgery. If two different blood types are mixed, it can lead to a clumping of blood cells that can be potentially fatal.
                    <a href="https://www.quora.com/Why-is-it-important-to-know-your-blood-type">Learn <br> More</a>
                </div>
            </div>
            <div class="clear"></div>
        </div>
    </section>
    <!--==============================
              footer
=================================-->
    <footer id="footer">
        <div class="container_12">
            <div class="grid_12">
                <h1 class="logo">
                    <a href="index.html">
          YFB
        </a>
                </h1>
                <div class="socials">
                    <a href="#" class="fa fa-twitter"></a>
                    <a href="#" class="fa fa-facebook"></a>
                    <a href="#" class="fa fa-google-plus"></a>
                    <a href="#" class="fa fa-pinterest"></a>
                </div>
                <div class="sub-copy">&copy; <span id="copyright-year"></span>| <a href="#">Privacy Policy</a> <br> Website designed by <a href="http://www.templatemonster.com/" rel="nofollow">WebSolution</a></div>
            </div>
            <div class="clear"></div>
        </div>
    </footer>
    <a href="#" id="toTop" class="fa fa-angle-up"></a>
</body>

</html>
